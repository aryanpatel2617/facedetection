import cv2
import os
import tkinter as tk
from tkinter import ttk
import pandas as pd
from utils import (BG_COLOR, BG_SECONDARY, CARD_COLOR, TEXT_COLOR, TEXT_SECONDARY,
                   PRIMARY_COLOR, SECONDARY_COLOR, BORDER_COLOR,
                   FONT_TITLE, FONT_BODY, FONT_SMALL, FONT_HEADER,
                   create_button, create_separator, show_error, show_info, center_window)

class CaptureApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Capture Faces")
        self.root.configure(bg=BG_COLOR)
        center_window(self.root, 480, 380)
        self.root.resizable(False, False)
        self.root.grab_set()
        
        self.users_df = pd.DataFrame()
        self.load_users()
        self.create_widgets()
        
    def load_users(self):
        try:
            csv_path = os.path.join("users", "users.csv")
            if os.path.exists(csv_path) and os.path.getsize(csv_path) > 0:
                self.users_df = pd.read_csv(csv_path)
        except Exception:
            pass
            
    def create_widgets(self):
        # Top accent bar
        tk.Frame(self.root, bg=SECONDARY_COLOR, height=3).pack(fill="x")
        
        # Header
        header = tk.Frame(self.root, bg=BG_SECONDARY, height=60)
        header.pack(fill="x")
        header.pack_propagate(False)
        
        lbl_icon = tk.Label(header, text="📸", font=("Segoe UI", 22), bg=BG_SECONDARY)
        lbl_icon.pack(side="left", padx=(25, 10))
        
        header_text = tk.Frame(header, bg=BG_SECONDARY)
        header_text.pack(side="left", fill="y", pady=8)
        tk.Label(header_text, text="CAPTURE FACES", font=FONT_HEADER, bg=BG_SECONDARY, fg=TEXT_COLOR).pack(anchor="w")
        tk.Label(header_text, text="Take 50 photos for training", font=FONT_SMALL, bg=BG_SECONDARY, fg=TEXT_SECONDARY).pack(anchor="w")
        
        tk.Frame(self.root, bg=BORDER_COLOR, height=1).pack(fill="x")
        
        # Content
        content = tk.Frame(self.root, bg=BG_COLOR, padx=30, pady=25)
        content.pack(fill="both", expand=True)
        
        lbl_select = tk.Label(content, text="SELECT USER", font=("Segoe UI", 9, "bold"), bg=BG_COLOR, fg=TEXT_SECONDARY)
        lbl_select.pack(anchor="w", pady=(0, 5))
        
        names = []
        if not self.users_df.empty:
            names = self.users_df['Name'].tolist()
        
        # Style the combobox
        style = ttk.Style()
        style.configure("Custom.TCombobox", fieldbackground=BG_SECONDARY, background=BG_SECONDARY, foreground=TEXT_COLOR)
            
        self.cb_users = ttk.Combobox(content, values=names, font=FONT_BODY, state="readonly")
        self.cb_users.pack(pady=(0, 20), ipady=5, fill="x")
        
        tk.Frame(content, bg=BORDER_COLOR, height=1).pack(fill="x", pady=(0, 20))
        
        btn_capture = create_button(content, "📷  Start Camera", self.start_capture, bg_color=SECONDARY_COLOR, width=20, height=2)
        btn_capture.pack()
        
        lbl_hint = tk.Label(content, text="💡 Look at the camera and turn your head slowly", font=FONT_SMALL, bg=BG_COLOR, fg=TEXT_SECONDARY)
        lbl_hint.pack(pady=(15, 0))
        
    def start_capture(self):
        selected_name = self.cb_users.get()
        if not selected_name:
            show_error("Error", "Please select a user first!")
            return
            
        user_folder = os.path.join("dataset", selected_name)
        if not os.path.exists(user_folder):
            os.makedirs(user_folder)
            
        cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        if not cap.isOpened():
            # Fallback to index 1 if 0 doesn't work
            cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)

        if not cap.isOpened():
            show_error("Error", "Webcam not found!")
            return
            
        # Using Haar Cascade for fast face detection during capture
        face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        
        count = 0
        max_images = 50
        
        show_info("Info", "Camera will open. Look at the camera and turn your head slightly. Wait until 50 images are captured.")
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break
                
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5, minSize=(100, 100))
            
            for (x, y, w, h) in faces:
                count += 1
                # Save just the cropped face to dataset
                face_img = frame[y:y+h, x:x+w]
                img_path = os.path.join(user_folder, f"img_{count}.jpg")
                cv2.imwrite(img_path, face_img)
                
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(frame, f"Captured: {count}/{max_images}", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                
            cv2.imshow('Capturing Faces - Press q to cancel', frame)
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
            # Check if window was closed by the user clicking 'X'
            if cv2.getWindowProperty('Capturing Faces - Press q to cancel', cv2.WND_PROP_VISIBLE) < 1:
                break
            if count >= max_images:
                break
                
        cap.release()
        cv2.destroyAllWindows()
        
        if count > 0:
            show_info("Success", f"Successfully captured {count} images for {selected_name}.")
            self.root.destroy()
        else:
            show_error("Error", "No faces were captured.")
